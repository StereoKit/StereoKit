using System;
using StereoKit;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            if (!StereoKitApp.Initialize("$safeprojectname$", Runtime.MixedReality))
                Environment.Exit(1);

            Model cube = Model.FromMesh(
                Mesh.GenerateRoundedCube(Vec3.One, 0.2f), 
                Default.Material);

            while (StereoKitApp.Step(() =>
            {
                cube.Draw(Matrix.TS(Vec3.Zero, 0.1f));
            }));

            StereoKitApp.Shutdown();
        }
    }
}
